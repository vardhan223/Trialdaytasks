/** Inverter.c
 *  Created: 17/06/2020 11:55:18 AM
 *  Author: Govardhan
 */

/**<-------- Pre-processor directives (Header files)------------------------------------ */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "processMeasurements.h"


/**<----------------- MACROS -------------------------------------------------------------- */
#define PI         3.14159
#define CYCLES     4                  // 4 full cycles
#define SAMPLES    360                // sample points in each cycle ( sample frequency = 1/128micro seconds =
#define WINDOWSIZE 4                  //  moving average window size






/**< --------------- Global variables -------------------------------------------------- */
float currentFiltered = 0;


measData p_measData;




/**< ----------------- Function definitions --------------------------------------------- */


/**< --------    Task - 1 (slide no:10)------------------  */


/** \brief  This function generates the inputs to the measured parameters ( sample frequency = 1/128microseconds  = 7.812 kHz)
            I am just considering the simple sine wave for current and voltage signals.
 * \param
 * \return All measured parameters
 *
 */

 static float measinputdata(void){

     int i=0, j=0;

     for(i=0; i<CYCLES; i++){

        for(j=0; j<SAMPLES;j++){
        p_measData->iRaw[j] = sin(2*PI*j/360);
        }
     }
 }


 /**< ---------------- Task - 2 (slide no:12) -------------------------------------------- */

 /**< Idea: Short circuit can be detected by checking the voltage across the line terminals.
 If the voltage is zero and high current measures by current sensor. Then it can be detected as
 a short circuit. Before that we need to detect the short circuit to protect the system. The digital
 solution is to use the Band pass filter (lower  cut-off : 50 Hz & Upper cut-off: 7.812 kHz(sample frequency)
 */

 /** \brief This function is used to detect the short circuit
  *
  * \param
  * \param
  * \return
  *
  */

static float shortcktDetect(void){



}



/**< ------------------- Task - 3 (slide no: 13, input current filter) -----------------------------*/

/**< Idea: From your slide, I understood that the moving average filter is used to smoothening the noisy signal from current sensor.
 It is a good idea,only using the addition and division. This leads to the lower computational power. From my thesis experience, I would
 prefer exponential smoothing filter. It is a simple low pass filter and needs low computational power( Yn = alpha*Xn + (1-alpha)*Yn-1; ).*/


/** \brief   This function filtering the measured data (moving average window size:4)
 *
 * \param
 * \param
 * \return  return the filtered current
 *
 */

float movAvg4(volatile float *currArray, unsigned int index){    // filter_In = (In-3 + In-2 + In-1 + In)/4

    float filtered_i = 0;

    filtered_i = (currArray[index-3]+ currArray[index-2] + currArray[index-1] + currArray[index])/ WINDOWSIZE; // make sure the initial values of array zero

    return filtered_i;

}


/**< -------------- Task - 4 (slide no :14, calculate RMS values) -----------------------------------*/


/** \brief    This function calculates the rms values of the grid system
 *
 * \param
 * \param
 * \return
 *
 */


 void calcRMS(struct measData *p_measData){
    float tempU = 0.0f;
    float tempI = 0.0f;
    float tempP = 0.0f;
    float reaP = 0.0f;

    const int numSamples = N_DATA_MEAS/2;

// sum of square for 4 full periods
    for (unsigned int k = p_measData->index - numSamples; k < p_measData->index; k++) {


    }

    p_measData->uRms = rmsU;
    p_measData->iRms = rmsI;
    p_measData->effP = effP;
    p_measData->appP = appP;
    p_measData->reaP = reaP;
    p_measData->cosPhi = cosPhi;
}




 /**< ---------------------- Task - 5 (slide no:15, Calculate voltage frequency) ----------------------- */

/** \brief This function calculates the frequency
 *
 * \param
 * \param
 * \return
 *
 */


 void calcFreq(struct measData *p_measData) {
    static int counter = 0;
    unsigned int index = p_measData->index;

}


/**< ----------------- Main function starts here -------------------------------------------- */

int main(void)
{

    printf("Hello world!\n");
    measinputdata();       // input signals generationj
    shortcktDetect();     // detection of short circuit
    currentFiltered =  movAvg4(measurements->i, measurements->index);  //filter current
    calcRMS(p_measData);     // calculate the rms values
    calcFreq(p_measData);    // calculate the frequency


    return 0;
}
