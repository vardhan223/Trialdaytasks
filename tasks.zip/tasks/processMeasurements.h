#ifndef PROCESSMEASUREMENTS_H_INCLUDED
#define PROCESSMEASUREMENTS_H_INCLUDED

#define N_DATA_MEAS (15625/25*2)   // # of measured points  //TODO functional, config: reduce to reasonable value, e.g. 4-10 periods, depending on standards and necessary update rate and RMS calculation from grid codes right now there are 8 periods

#define N_Wicklungen 5

#define currFactor		(1/(53278.0F*N_Wicklungen)) //Faktor um AFE Signal auf echte Amp�re zu skalieren
#define voltFactor  	(1/25331.0F)	//Faktor um AFE Signal auf echte Volt zu skalieren


/**
 * @brief struct for measeurement data
 */
typedef struct measData             //struct containing grid measurements
{
    volatile float i[N_DATA_MEAS];   //vector for current measurement data
    volatile float u[N_DATA_MEAS];   //vector for voltage measurement data
    int iRaw[N_DATA_MEAS];          //vector for raw current measurement data
    int uRaw[N_DATA_MEAS];          //vector for raw voltage measurement data
    volatile unsigned int index; //index to measurement array
    // calculated values
    volatile float uD;  //calculated direct voltage component
    volatile float uQ;  //calculated quadrature voltage component
    float uRms;     //effective voltage
    float iRms;     //effective current
    float effP;     // effective power (Wirkleistung)
    float appP;     // apparent power (scheinleistung)
    float reaP;     // reactive power
    float cosPhi;   // cosinus phi
    volatile float freq; //calculated grid frequency
}measData;

measData p_measData;


// input signal generation



// data processing
float movAvg4(volatile float *currArray, unsigned int index);
float filterVdVq(measData *a);




//calculating power data
void calcRMS(struct measData *p_measData);
void calcFreq(struct measData *p_measData);





#endif // PROCESSMEASUREMENTS_H_INCLUDED
